import { Component } from '@angular/core';

@Component({
  selector: 'app-tarjeta-chats',
  templateUrl: './tarjeta-chat.component.html',
  styleUrls: ['./tarjeta-chat.component.css']
})
export class TarjetaChatComponent {

}
