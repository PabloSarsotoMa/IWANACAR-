import { Component } from '@angular/core';

@Component({
  selector: 'app-viaje-publicado',
  templateUrl: './viaje-publicado.component.html',
  styleUrls: ['./viaje-publicado.component.css']
})
export class ViajePublicadoComponent {

}
