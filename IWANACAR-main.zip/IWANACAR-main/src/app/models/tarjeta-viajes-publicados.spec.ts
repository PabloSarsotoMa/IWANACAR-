import { TarjetaViajesPublicados } from './tarjeta-viajes-publicados';

describe('TarjetaViajesPublicados', () => {
  it('should create an instance', () => {
    expect(new TarjetaViajesPublicados()).toBeTruthy();
  });
});
