export class TarjetaViaje {
    public foto:string;
    public nombre:string;
    public hora:string;
    public fecha:string;
    public precio:Number;
    public pasajeros: number;
    public origen: string;
    public destino: string;
    public id_viaje:number;
    public id_conductor: number;
    constructor(){}

}