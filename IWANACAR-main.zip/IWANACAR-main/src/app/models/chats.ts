export class Chats {
}
