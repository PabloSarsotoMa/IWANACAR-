export class BuscarViaje {
    public foto:string;
    public nombre:string;
    public hora:string;
    public fecha:string;
    public precio:Number;
    public pasajeros: number;
    public direccionOrigen: string;
    public direccionDestino: string;

    constructor(){}
    
}